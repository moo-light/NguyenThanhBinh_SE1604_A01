﻿namespace BusinessObject
{
    public class BaseEntity
    {
    }
}