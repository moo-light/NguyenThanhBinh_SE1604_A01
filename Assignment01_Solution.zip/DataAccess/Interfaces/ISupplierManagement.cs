﻿using BusinessObject;

namespace DataAccess.Interfaces
{
    public interface ISupplierManagement : IGenericManagement<Supplier>
    {
    }
}