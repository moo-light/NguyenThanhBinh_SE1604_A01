﻿using BusinessObject;

namespace DataAccess.Interfaces
{
    public interface IOrderDetailManagement : IGenericManagement<OrderDetail>
    {
    }
}