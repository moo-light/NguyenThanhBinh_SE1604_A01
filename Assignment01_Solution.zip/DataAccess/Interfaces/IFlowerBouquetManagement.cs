using BusinessObject;

namespace DataAccess.Interfaces;

public interface IFlowerBouquetManagement : IGenericManagement<FlowerBouquet>
{

}