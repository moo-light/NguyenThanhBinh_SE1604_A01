﻿using BusinessObject;

namespace DataAccess.Interfaces
{
    public interface ICategoryManagement : IGenericManagement<Category>
    {
    }
}